## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/create-a-php-login-and-registration-system-from-scratch-2020-video/9781800569836)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Create-a-PHP-Login-and-Registration-System-From-Scratch-2020
Create a PHP Login and Registration System From Scratch 2020 by Packt Publishing
